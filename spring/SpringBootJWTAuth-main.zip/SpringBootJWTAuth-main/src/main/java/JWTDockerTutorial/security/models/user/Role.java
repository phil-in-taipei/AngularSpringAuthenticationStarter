package JWTDockerTutorial.security.models.user;

public enum Role {
    USER,
    ADMIN
}
