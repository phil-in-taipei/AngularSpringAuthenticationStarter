package JWTDockerTutorial.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Profile;

@SpringBootTest
class SecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
